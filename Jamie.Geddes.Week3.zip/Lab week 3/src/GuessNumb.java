import java.util.Random;
import java.util.Scanner;
public class GuessNumb {

	public static void main(String[] args) {

		
	int Easy; // 0-100
	int Medium; // 0-500
	int Hard; // 0-1000
		
	System.out.println("Enter the Difficulty : 1 = Easy, 2 = Medium , 3 = Difficult");
	int difficulty;
	Scanner scan= new Scanner( System.in );
	difficulty = scan.nextInt();
	
	int number = 0;
	
	switch (difficulty) {
	case 1:
		Random randomnumber = new Random();
		number = randomnumber.nextInt(101); //difficulty up to 100
		break;
	case 2:
		Random randomnumber2 = new Random();
		number = randomnumber2.nextInt(501); //difficulty up to 500
		break;
	case 3:
		Random randomnumber3 = new Random();
		number = randomnumber3.nextInt(1001); //difficulty up to 1000
		break;
	}
	
	
	int num1;
	System.out.println("Enter Guess:");
	num1 = scan.nextInt();
	
	if(num1 == number){
		System.out.println("You won!");
	} else if(num1 > number){
		System.out.print(""); // left blank as other part prints the required things
	} else{
		System.out.print(""); // left blank as other part prints the required things
		
	}
	
	while(num1<number){
		System.out.println("Please try again"); //repeats if too small
		System.out.println("Pick a larger number");
		num1 = scan.nextInt();
		
	}
		
	
		
	
	
	while(num1>number){
		System.out.println("Please try again"); //repeats if too high
		System.out.println("You are too high!");
		num1 = scan.nextInt();
	
	}
		
	}
		
		
	}

	
	
	
