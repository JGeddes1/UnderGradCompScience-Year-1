
public class number1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int value = 12;
if (value%2==0)
{
	System.out.println("True");}
	}

}
